<?php
/**
 * Uninstall file for WhatsApp Float Button
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Option name used in plugin (match your main plugin option constant)
delete_option( 'wfb_options' );

// If you created site options (multisite), remove them too:
if ( is_multisite() ) {
    delete_site_option( 'wfb_options' );
}
