/**
 * Handles WhatsApp app deep-linking with fallback to WhatsApp Web (wa.me)
 */
( function ( $ ) {
	'use strict';

	$( function () {
		var $btn = $( '.wfb-float-button' );

		// Add dynamic side class (left/right) to container wrapper
		$( '.wfb-float-wrap' ).each( function () {
			var $wrap = $( this ),
				$btn = $wrap.find( '.wfb-float-button' ),
				sideClass = $btn.hasClass( 'wfb-left' ) ? 'wfb-left' : 'wfb-right'; // fallback

			// We store side on anchor attribute: class wfb-side-left or right is applied via markup already.
			// Nothing else required here unless you want to adjust offsets via JS.
		} );

		// Behavior on click: attempt app first, fallback to web (useful on mobile)
		$btn.on( 'click', function ( e ) {
			var openIn = ( typeof wfbOptions !== 'undefined' && wfbOptions.open_in ) ? wfbOptions.open_in : 'app';
			var appUrl = $( this ).data( 'app' );
			var waMe = $( this ).data( 'wa-me' );
			var isMobile = /Mobi|Android/i.test( navigator.userAgent );

			// If user chose 'web' open wa.me directly
			if ( openIn === 'web' ) {
				// Respect target_blank preference in server-rendered markup
				return true; // let normal anchor behavior proceed
			}

			// Only attempt deep linking on mobile devices
			if ( openIn === 'app' && isMobile ) {
				e.preventDefault();

				// Try to open app scheme and fall back to wa.me after timeout
				var now = Date.now();
				var timeout = setTimeout( function () {
					// fallback: open wa.me
					if ( wfbOptions && wfbOptions.target_blank ) {
						window.open( waMe, '_blank', 'noopener' );
					} else {
						window.location.href = waMe;
					}
				}, 800 );

				// Attempt to open the whatsapp protocol. Some browsers may ignore it or show a prompt.
				window.location = appUrl;

				// If page becomes hidden (app opened), clear fallback
				var hiddenChange = function () {
					clearTimeout( timeout );
					document.removeEventListener( 'visibilitychange', hiddenChange );
				};
				document.addEventListener( 'visibilitychange', hiddenChange );
			}
			// Otherwise, let anchor behave (web link)
		} );
	} );
} )( jQuery );
