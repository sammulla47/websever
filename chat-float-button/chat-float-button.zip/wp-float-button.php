<?php

/**
 * Plugin Name: Chat Float Button
 * Plugin URI:  https://websemporium.co.in/chat-float-button
 * Description: Floating Whatapp button with admin settings, app & web support, positioning, and mobile controls.
 * Version:     1.0.0
 * Author:      Websemporium
 * Author URI:  https://websemporium.co.in
 * Text Domain: chat-float-button
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (! defined('ABSPATH')) {
	exit;
}

define('WFB_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WFB_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WFB_OPTION_NAME', 'wfb_options');

/**
 * Default options
 */
function wfb_default_options()
{
	return array(
		'enabled'         => 1,
		'phone'           => '',
		'message'         => '',
		'hover_text'      => __('Chat with us!', 'chat-float-button'),
		'position_side'   => 'right',
		'position_bottom' => 10,
		'hide_on_mobile'  => 0,
		'open_in'         => 'app', // app | web
		'icon'            => '',
		'target_blank'    => 1,
	);
}

/**
 * Register settings
 */
add_action('admin_init', function () {
	register_setting(
		'wfb_settings_group',
		WFB_OPTION_NAME,
		'wfb_sanitize_options'
	);
});

/**
 * Sanitize options (ALL USED)
 */
function wfb_sanitize_options($input)
{

	$output = wfb_default_options();

	$output['enabled']         = ! empty($input['enabled']) ? 1 : 0;
	$output['phone']           = isset($input['phone']) ? sanitize_text_field($input['phone']) : '';
	$output['message']         = isset($input['message']) ? sanitize_textarea_field($input['message']) : '';
	$output['hover_text']      = isset($input['hover_text']) ? sanitize_text_field($input['hover_text']) : '';
	$output['position_side']   = in_array($input['position_side'] ?? '', array('left', 'right'), true) ? $input['position_side'] : 'right';
	$output['position_bottom'] = isset($input['position_bottom']) ? max(0, min(100, (int) $input['position_bottom'])) : 10;
	$output['hide_on_mobile']  = ! empty($input['hide_on_mobile']) ? 1 : 0;
	$output['open_in']         = in_array($input['open_in'] ?? '', array('app', 'web'), true) ? $input['open_in'] : 'app';
	$output['icon']            = isset($input['icon']) ? sanitize_text_field($input['icon']) : '';
	$output['target_blank']    = ! empty($input['target_blank']) ? 1 : 0;

	return $output;
}

/**
 * Admin menu
 */
add_action('admin_menu', 'wfb_admin_menu');
function wfb_admin_menu()
{

	add_menu_page(
		__('Chat Float Button', 'chat-float-button'), // Page title
		__('Chat Float', 'chat-float-button'),        // Menu title
		'manage_options',                                      // Capability
		'wfb-settings',                                        // Menu slug
		'wfb_settings_page',                                   // Callback
		'dashicons-whatsapp',                                  // Icon
		58                                                      // Position
	);
}
/**
 * Get available icon files from plugin folder
 */
function wfb_get_icon_list() {

	$icons = array();
	$dir   = WFB_PLUGIN_DIR . 'assets/icons/';

	if ( is_dir( $dir ) ) {
		$files = glob( $dir . '*.{png,jpg,jpeg,svg,gif}', GLOB_BRACE );
		if ( $files ) {
			foreach ( $files as $file ) {
				$icons[] = str_replace( WFB_PLUGIN_DIR, '', $file );
			}
		}
	}

	return $icons;
}

/**
 * Admin settings page (ALL OPTIONS PRESENT)
 */
function wfb_settings_page()
{
	$options = get_option(WFB_OPTION_NAME, wfb_default_options());
	$icons = wfb_get_icon_list();
    $message = 'Hello! I visited your website and have a question. Could you please assist me? Thank you.';
?>
	<div class="wrap">
		<h1><?php esc_html_e('Chat Float Button', 'chat-float-button'); ?></h1>

		<form method="post" action="options.php">
			<?php settings_fields('wfb_settings_group'); ?>

			<table class="form-table">

				<tr>
					<th><?php esc_html_e('Enable Button', 'chat-float-button'); ?></th>
					<td><input type="checkbox" name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[enabled]" value="1" <?php checked(1, $options['enabled']); ?>></td>
				</tr>

				<tr>
					<th><?php esc_html_e('Whatapp Number', 'chat-float-button'); ?></th>
					<td><input type="text" class="regular-text" name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[phone]" value="<?php echo esc_attr($options['phone']); ?>"></td>
				</tr>

				<tr>
					<th><?php esc_html_e('Message', 'chat-float-button'); ?></th>
					<td><textarea class="large-text" name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[message]" rows="4"><?php echo esc_textarea( $message ); ?></textarea></td>
				</tr>

				<tr>
					<th><?php esc_html_e('Hover Text', 'chat-float-button'); ?></th>
					<td><input type="text" class="regular-text" name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[hover_text]" value="<?php echo esc_attr($options['hover_text']); ?>"></td>
				</tr>

				<tr>
					<th><?php esc_html_e('Position Side', 'chat-float-button'); ?></th>
					<td>
						<select name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[position_side]">
							<option value="left" <?php selected('left', $options['position_side']); ?>>Left</option>
							<option value="right" <?php selected('right', $options['position_side']); ?>>Right</option>
						</select>
					</td>
				</tr>

				<tr>
					<th><?php esc_html_e('Bottom Position (%)', 'chat-float-button'); ?></th>
					<td><input type="number" min="0" max="100" name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[position_bottom]" value="<?php echo esc_attr($options['position_bottom']); ?>"></td>
				</tr>
				<tr>
					<th><?php esc_html_e('Button Icon', 'chat-float-button'); ?></th>
					<td>
						<select name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[icon]">
							<option value=""><?php esc_html_e('Default Icon', 'chat-float-button'); ?></option>

							<?php foreach ($icons as $icon) : ?>
								<option value="<?php echo esc_attr($icon); ?>"
									<?php selected($options['icon'], $icon); ?>>
									<?php echo esc_html(basename($icon)); ?>
								</option>
							<?php endforeach; ?>
						</select>

						<p class="description">
							<?php esc_html_e('Icons are loaded from the plugin folder: assets/icons/', 'chat-float-button'); ?>
						</p>

						<?php if (! empty($options['icon']) && file_exists(WFB_PLUGIN_DIR . $options['icon'])) : ?>
							<p style="margin-top:8px;">
								<img src="<?php echo esc_url(WFB_PLUGIN_URL . $options['icon']); ?>"
									alt=""
									style="width:48px;height:auto;border:1px solid #ddd;padding:6px;">
							</p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e('Hide on Mobile', 'chat-float-button'); ?></th>
					<td><input type="checkbox" name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[hide_on_mobile]" value="1" <?php checked(1, $options['hide_on_mobile']); ?>></td>
				</tr>

				<tr>
					<th><?php esc_html_e('Open In', 'chat-float-button'); ?></th>
					<td>
						<label><input type="radio" name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[open_in]" value="app" <?php checked('app', $options['open_in']); ?>> App</label><br>
						<label><input type="radio" name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[open_in]" value="web" <?php checked('web', $options['open_in']); ?>> Web</label>
					</td>
				</tr>

				<tr>
					<th><?php esc_html_e('Open in New Tab', 'chat-float-button'); ?></th>
					<td><input type="checkbox" name="<?php echo esc_attr(WFB_OPTION_NAME); ?>[target_blank]" value="1" <?php checked(1, $options['target_blank']); ?>></td>
				</tr>

			</table>

			<?php submit_button(); ?>
		</form>
	</div>
<?php
}

/**
 * Enqueue frontend assets
 */
add_action('wp_enqueue_scripts', function () {

	wp_enqueue_style(
		'wfb-style',
		WFB_PLUGIN_URL . 'assets/css/style.css',
		array(),
		'1.0.0'
	);

	wp_enqueue_script(
		'wfb-script',
		WFB_PLUGIN_URL . 'assets/js/widget.js',
		array('jquery'),
		'1.0.0',
		true
	);

	$options = get_option(WFB_OPTION_NAME, wfb_default_options());

	wp_localize_script(
		'wfb-script',
		'wfbOptions',
		array(
			'open_in'      => $options['open_in'],
			'target_blank' => $options['target_blank'],
		)
	);
});

/**
 * Frontend output (ALL OPTIONS USED)
 */
add_action('wp_footer', function () {

	$options = get_option(WFB_OPTION_NAME, wfb_default_options());
    
    if (empty($options['enabled'])) {
        return;
    }

	if (empty($options['phone'])) {
		return;
	}

	$phone   = preg_replace('/[^0-9]/', '', $options['phone']);
	$message = rawurlencode($options['message']);

	$wa_url  = 'https://wa.me/' . $phone . ($message ? '?text=' . $message : '');
	$app_url = 'whatsapp://send?phone=' . $phone . ($message ? '&text=' . $message : '');

	$mobile_class = ! empty($options['hide_on_mobile']) ? ' wfb-hide-mobile' : '';
?> 
	<div class="wfb-float-wrap wfb-<?php echo esc_attr($options['position_side'] . $mobile_class); ?>"
		style="bottom:<?php echo esc_attr((int) $options['position_bottom']); ?>%;">

		<a href="<?php echo esc_url($wa_url); ?>"
			class="wfb-float-button"
			data-wa-me="<?php echo esc_url($wa_url); ?>"
			data-app="<?php echo esc_url($app_url); ?>"
			title="<?php echo esc_attr($options['hover_text']); ?>"
			<?php if (! empty($options['target_blank'])) : ?>
			target="_blank" rel="noopener noreferrer"
			<?php endif; ?>>

			<span class="wfb-icon-wrap">
				<?php if (! empty($options['icon']) && file_exists(WFB_PLUGIN_DIR . $options['icon'])) : ?>
					<img src="<?php echo esc_url(WFB_PLUGIN_URL . $options['icon']); ?>"
						alt="<?php esc_attr_e('WhatsApp Icons', 'chat-float-button'); ?>">
				<?php else : ?>
					<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true">
						<path fill="#fff" d="M20.5 3.5A11.9 11.9 0 0 0 12 .5A11.9 11.9 0 0 0 .5 12c0 2 .5 3.9 1.5 5.6L.5 23.5l5-1.3A11.66 11.66 0 0 0 12 23.5a11.9 11.9 0 0 0 8.5-3.5A11.9 11.9 0 0 0 23.5 12a11.9 11.9 0 0 0-3-8.5z" />
					</svg>
				<?php endif; ?>
			</span>
<?php if ( ! empty( $options['hover_text'] ) ) : ?>
		<span class="wfb-tooltip">
			<?php echo esc_html( $options['hover_text'] ); ?>
		</span>
	<?php endif; ?>
		</a>
    
	</div>
<?php
});
