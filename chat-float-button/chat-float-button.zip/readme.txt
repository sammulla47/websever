=== Chat Float Button ===
Contributors: websemporium
Tags: wp, chat, floating button, contact, live chat
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Chat Float Button adds a floating WhatsApp contact button to the front end of your website.

The plugin provides a dedicated admin menu and flexible settings that allow you to control the button’s position, behavior, and appearance. It supports opening WhatsApp directly in the mobile app when available, with an automatic fallback to WhatsApp Web (wa.me).

This plugin is lightweight, secure, and follows WordPress coding standards.

**Key features:**
* Floating WhatsApp button on the frontend
* Top-level admin menu for easy access
* Open WhatsApp in the app or via WhatsApp Web fallback
* Single phone number with prefilled message
* Left or right positioning
* Adjustable bottom position (percentage based)
* Option to hide the button on mobile devices
* Custom hover text (tooltip)
* Optional opening in a new tab
* Icon loaded directly from the plugin folder

== Installation ==
1. Upload the `chat-float-button` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Go to **WP Float** in the admin menu to configure the settings.

== Frequently Asked Questions ==

= Does this plugin open WhatsApp in the app or browser? =
On mobile devices, the plugin attempts to open the WhatsApp app if it is installed. If the app is not available, it falls back to WhatsApp Web using a wa.me link.

= Can I control where the button appears? =
Yes. You can choose left or right alignment and adjust the bottom position using a percentage value.

= Can I hide the button on mobile devices? =
Yes. The plugin includes an option to hide the floating button on mobile screens.

= Is this plugin free? =
Yes. This plugin is completely free and licensed under GPLv2 or later.

== Screenshots ==
1. Admin settings page.
2. Frontend floating WhatsApp button.

== Changelog ==
= 1.0.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.0 =
Initial release.
